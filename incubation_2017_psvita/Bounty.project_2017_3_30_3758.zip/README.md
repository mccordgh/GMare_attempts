Documentation:
Go to the [wiki](https://bitbucket.org/incubation2017/core/wiki/Home)!